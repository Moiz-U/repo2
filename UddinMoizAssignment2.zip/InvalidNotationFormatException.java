public class InvalidNotationFormatException extends RuntimeException {
	public InvalidNotationFormatException() {
		super("This is not the valid form");
	}
}
