import java.util.ArrayList;

/**
 * This class incorporates queue while converting from infix to postfix.
 * @author Moiz Uddin
 */


public class MyQueue<T> implements QueueInterface<T> {
	
	private static int DEFAULT_LENGTH = 10;
	private T[] queue;
	private int size;
	public static final int MAX_LENGTH = 99;
	
	/**
	 * METHOD GETS AND RETURNS SIZE
	 * 
	 * @return size - SIZE OF QUEUE ARRAYLIST
	 */
	public int size() {
		return size;
	}

	/**
	 * Constructor that calls other constructor
	 */
	public MyQueue() {
		this(DEFAULT_LENGTH);
	}

	/**
	 * Constructor with parameter
	 * 
	 * @param capacity - CAPACITY OF ARRAY BY USER
	 */
	@SuppressWarnings("unchecked")
	public MyQueue(int capacity) {
		if (capacity <= MAX_LENGTH) {
			queue = (T[]) new Object[capacity];
			size = 0;
		} else {
			throw new IllegalStateException("This array is larger than the max, try again.");
		}

	}

	
	/**
	 * Fills the queue with the different parts of the ArrayList
	 * @param list - ArrayList that will all end up being copied to queue
	 */
	@SuppressWarnings("unchecked")
	public void fill(ArrayList<T> list) {
		ArrayList<T> copyList = list;
		queue = (T[]) copyList.toArray();
		size = copyList.size();
	}

	/**
	 * Removes first object and shifts them by an increment of 1
	 * 
	 * @throws QueueUnderflowException
	 * @return result
	 */
	public T dequeue() throws QueueUnderflowException {

		if (isEmpty())
			throw new QueueUnderflowException();
		T result = queue[0];
		for (int count = 0; count < queue.length; count++) {
			if (count != queue.length - 1)
				queue[count] = queue[count + 1];
		}
		size--;
		return result;
	}
	
	/**
	 * 
	 * @param entry, given by user
	 * @throws QueueOverflowException 
	 * @return true
	 */
	public boolean enqueue(T entry) throws QueueOverflowException {

		if (isFull()) {
			throw new QueueOverflowException();
		}
		queue[size] = entry;
		size++;
		return true;

	}

	/**
	 * Turns all values of queue into a single string
	 * 
	 * @return toStr
	 */
	public String toString() {
		String toStr = "";
		for (int i = 0; i < size; i++) {
			toStr += queue[i];
		}
		return toStr;
	}

	/**
	 * turns all the values into a string except with delimiter in between
	 * 
	 * @return toStr
	 */
	public String toString(String delimiter) {
		String toStr = "";
		for (int count = 0; count < size; count++) {
			toStr += queue[count] + delimiter;
		}
		return toStr.substring(0, toStr.length() - 1);
	}

	/**
	 * Checks if queue is empty
	 * 
	 * @return true
	 * @return false
	 */
	public boolean isEmpty() {
		return queue[0] == null;
	}

	/**
	 * Checks if queue is completely full
	 * 
	 * @return true
	 * @return false
	 */
	public boolean isFull() {
		return size == queue.length;
	}
}