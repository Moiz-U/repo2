import java.util.ArrayList;

public class MyStack<T> implements StackInterface<T> {

	private static final int DEFAULT_LENGTH = 10;
	public static final int MAX_LENGTH = 99;
	private T[] stack;
	int size;

	public MyStack() {
		this(DEFAULT_LENGTH);
	}

	
	/**
	 * Constructor with parameter
	 * 
	 * @param capacity - CAPACITY OF ARRAY BY USER
	 */
	@SuppressWarnings("unchecked")
	public MyStack(int capacity) {
		if (capacity <= MAX_LENGTH) {
			stack = (T[]) new Object[capacity];
			size = 0;
		} else {
			throw new IllegalStateException("Array size is above the max size");
		}

	}

	public boolean isEmpty() {
		return size == 0;
	}

	public boolean isFull() {
		return size == stack.length;
	}

	public T pop() throws StackUnderflowException {
		if (isEmpty())
			throw new StackUnderflowException();
		T output = stack[size - 1];
		stack[size--] = null;
		return output;
	}

	public T top() throws StackUnderflowException {
		if (isEmpty())
			throw new StackUnderflowException();
		return stack[size - 1];
	}

	
	/**
	 * METHOD GETS AND RETURNS SIZE
	 * 
	 * @return size - SIZE OF QUEUE ARRAYLIST
	 */
	public int size() {
		return size;
	}

	public boolean push(T entry) throws StackOverflowException {
		if (isFull())
			throw new StackOverflowException();
		stack[size++] = entry;
		return true;
	}

	/**
	 * Turns all values of queue into a single string
	 * 
	 * @return toStr
	 */
	public String toString() {
		String str = "";
		for (int i = 0; i < size; i++) {
			str += stack[i];
		}
		return str;
	}

	/**
	 * turns all the values into a string except with delimiter in between
	 * 
	 * @return toStr
	 */
	public String toString(String delimiter) {
		String str = "";
		for (int i = 0; i < size; i++) {
			str += stack[i] + delimiter;
		}
		return str.substring(0, str.length() - 1);
	}

	/**
	 * Fills the queue with the different parts of the ArrayList
	 * @param list - ArrayList that will all end up being copied to queue
	 */
	@SuppressWarnings("unchecked")
	public void fill(ArrayList<T> list) {
		ArrayList<T> copyList = list;
		for(int i = 0; i < copyList.size(); i++)
		{
			stack[i] = copyList.get(i);
		}
		size = copyList.size();

	}

}