public class CourseDBElement implements Comparable<CourseDBElement> {
	private String id;
	private int crn;
	private int numCredit;
	private String roomNum;
	private String name;
	
	
	
	public CourseDBElement(String id, int crn, int numCredits, String roomNum, String name) {
		this.id=id;
		this.crn=crn;
		this.numCredit=numCredits;
		this.roomNum=roomNum;
		this.name=name;
	}
	
	/** 
	 * getters and setters
	 */

	public String getID() {
		return id;
	}
	
	public int getCRN() {
		return crn;
	}
	
	public int getCredits() {
		return numCredit;
	}
	
	public String getRoomNum() {
		return roomNum;
	}

	public String getinstructorName() {
		return name;
	}

	public void setID(String ID) {
		this.id = ID;
	}
	
	public void setCRN(int CRN) {
		this.crn = CRN;
	}

	public void setCredits(int credits) {
		this.numCredit = credits;
	}
	
	public void setRoomNum(String roomNumber) {
		this.roomNum = roomNumber;
	}

	public void setinstructorName(String instructorName) {
		this.name = instructorName;
	}
	
	/**
	 * 
	 * other methods to be implemented in the class
	 * 
	 **/
	
	/**
	 * creates an empty entry for the course elements
	 */
	public CourseDBElement() {
		this(null,00000,0,null,null);
	}
	
	public CourseDBElement(int CRN) {
		this.crn=CRN;
	}
	
	public String getHash() {
		return "" + crn;
	}
	
	@Override
	public int compareTo(CourseDBElement object) {
		return 0;
	}

	/**
	 * toString method to convert into a string
	 */
	
	@Override
	public String toString() {
		String s = "\ncourse name:" + id + " crn:" + crn + " number of credits:" + numCredit + " instructor:" + name
				+ " room number:" + roomNum;
		return s;
	}
	
}