import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class CourseDBManager implements CourseDBManagerInterface {
	private CourseDBStructure CDS;

	public CourseDBManager() {
		CDS = new CourseDBStructure(20);
	}

    @Override
    public void add(String id, int crn, int numCredit, String roomNum, String name) {
            CourseDBElement newElement = new CourseDBElement(id, crn, numCredit, roomNum, name);
            CDS.add(newElement);
    }

    @Override
    public CourseDBElement get(int crn) {
            try {
                    return CDS.get(crn);
            } catch (IOException e) {
                    e.getMessage();
            }
            return null;
    }

	@Override
	public void readFile(File input) throws FileNotFoundException {
		 try {
             Scanner scan = new Scanner(input);
             while(scan.hasNext()) {
                     String id = scan.next();
                     int crn = scan.nextInt();
                     int numCredit = scan.nextInt();
                     String roomNum = scan.next();
                     String instructor = scan.nextLine();
                     add(id, crn, numCredit, roomNum, instructor);
             }
             scan.close();
     }
     catch(FileNotFoundException e) {
             System.out.print("file cannot be found");
             e.getMessage();
     }
	}


	@Override
	public ArrayList<String> showAll() {
		return CDS.showAll();
	}

}