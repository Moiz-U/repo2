import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedList;

public class CourseDBStructure implements CourseDBStructureInterface {

	protected int tableS;
	protected ArrayList<LinkedList<CourseDBElement>> hashing;
	private final double loadFactor = 1.5;

	public CourseDBStructure(String str, int num) {
		tableS = num;
		hashing = new ArrayList<LinkedList<CourseDBElement>>(tableS);
		for (int i = 0; i < tableS; i++) {
			hashing.add(new LinkedList<CourseDBElement>());
		}
	}


	@Override
	public void add(CourseDBElement element) {
		int index = Integer.parseInt(element.getHash()) % tableS;

		if (!(hashing.get(index).contains(element))) {
			hashing.get(index).add(element);
		}

		for (int i = 0; i < hashing.get(index).size(); i++) {
			if (!((CourseDBElement) hashing.get(index).get(i)).getID().equals(element.getID())) {
				if (((CourseDBElement) hashing.get(index).get(i)).getCRN() == element.getCRN()) {
					hashing.get(index).remove(i);
					hashing.get(index).add(element);
				}
			}
		}

	}
	
	public CourseDBStructure(int number) {
		int i = (int) (number / loadFactor);
		for (int k = 0; k < i; k++) {
			if ((4 * k + 3) > i) {
				if (isPrime(4 * k + 3)) {
					int size = 4 * k + 3;
					tableS = size;
					break;
				}
			}
		}

		hashing = new ArrayList<LinkedList<CourseDBElement>>(tableS);
		for (int j = 0; j < tableS; j++) {
			hashing.add(new LinkedList<CourseDBElement>());
		}
	}


	@Override
	public CourseDBElement get(int crn) throws IOException {
		int index = crn % tableS;
		if (!(hashing.get(index).isEmpty())) {
			for (int i = 0; i < hashing.get(index).size(); i++) {
				if (((CourseDBElement) hashing.get(index).get(i)).getCRN() == crn)
					return ((CourseDBElement) hashing.get(index).get(i));
			}
		}
		throw new IOException();

	}


	@Override
	public ArrayList<String> showAll() {
		ArrayList<String> all = new ArrayList<String>(tableS);

		for (int i = 0; i < tableS; i++) {
			if (!(hashing.get(i).isEmpty())) {
				all.add(hashing.get(i).toString().replace("[", "").replace("]", ""));
			}
		}
		return all;
	}


	@Override
	public int getTableSize() {
		// TODO Auto-generated method stub
		return tableS;
	}


	private static boolean isPrime(int num) {
		boolean prime = false;
		if (num <= 1) {
			return prime;
		}
		return prime;
		
	}

}