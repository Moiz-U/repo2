import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;
import static org.junit.jupiter.api.Assertions.*;

import java.io.File;
import java.io.PrintWriter;
import java.util.ArrayList;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class CourseDBManager_STUDENT_Test {
        private CourseDBManagerInterface tester = new CourseDBManager();
        @BeforeEach
        void setUp() throws Exception {
                tester = new CourseDBManager();
        }

        @AfterEach
        void tearDown() throws Exception {
                tester = null;
        }

        @Test
        void testAddToDB() {
                try {
                        tester.add("MATH181",22122,4,"Online","Professor John");
                }
                catch(Exception e) {
                        fail("Exception should not occur");
                }
        }
        
        @Test
        void testShowAll() {
                tester.add("MATH182",12345,2,"421","Professor Diggs");
                tester.add("PSYC102",64321,1,"Online","Professor Bobby");
                ArrayList<String> list = tester.showAll();
                
                assertEquals(list.get(0),"\ncourse:MATH182 CRN:12345 Credits:2 Instructor:Professor Diggs Room:421");
                assertEquals(list.get(1),"\ncourse:PSYC102 CRN:64321 Credits:1 Instructor:Professor Bobby Room:Online");
        }
        
        @Test
        void testReadFile() {
                try {
                        File inputFile = new File("Test1.txt");
                        PrintWriter inFile = new PrintWriter(inputFile);
                        inFile.println("MATH182 12345 2 421 Joey Professor Diggs");
                        inFile.print("PSYC102 64321 1 Online Professor Bobby");
                        inFile.close();
                        tester.readFile(inputFile);
                } catch (Exception e) {
                        fail("Exception should not occur");
                }
        }

}