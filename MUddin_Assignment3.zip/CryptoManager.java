/*
 * Class: CMSC203 
 * Instructor: Professor Mister Doctor Kuijt
 * Description: Encrypt and decrypt a special password using the Caesar and Bellaso encryption methods
 * Due: 10/18/2021
 * Platform/compiler: Eclipse 
 * I pledge that I have completed the programming assignment independently.
   I have not copied the code from a student or any source.
   I have not given my code to any student.
   Print your Name here: Moiz Uddin
*/

public class CryptoManager {
	
	private static final char LOWER_BOUND = 32;
	private static final char UPPER_BOUND = 95;
	private static final int RANGE = UPPER_BOUND - LOWER_BOUND + 1;

	/**
	 * This method determines if a string is within the allowable bounds of ASCII codes 
	 * according to the LOWER_BOUND and UPPER_BOUND characters
	 * @param plainText a string to be encrypted, if it is within the allowable bounds
	 * @return true if all characters are within the allowable bounds, false if any character is outside
	 */
	public static boolean stringInBounds (String plainText) {  //Tests if user input string password is in the boundaries
		boolean isInBounds = true;
		int asciiFinder;//ascii of character
		//for loop to check each letter of string to see if it fits in ascii boundaries
		for(int i=0;i<plainText.length();i++) {
			asciiFinder=plainText.charAt(i);
			if(asciiFinder>=LOWER_BOUND && asciiFinder<=UPPER_BOUND) {
				return isInBounds;
			}
		}
		isInBounds = false;
		return isInBounds;
	}

	/**
	 * Encrypts a string according to the Caesar Cipher.  The integer key specifies an offset
	 * and each character in plainText is replaced by the character \"offset\" away from it 
	 * @param plainText an uppercase string to be encrypted.
	 * @param key an integer that specifies the offset of each character
	 * @return the encrypted string
	 */
	public static String encryptCaesar(String plainText, int key) { //encrypts the users password using the Caesar
		//cipher and incorporates the given key
		int beforeCipher;  //ascii of character before cipher
		int afterCipher;  //ascii of character after cipher
		String caeserCipher = "";  //encryption which adds on the next character
		for(int i=0;i<plainText.length();i++) {
			beforeCipher = plainText.charAt(i);
			afterCipher = key+beforeCipher;
			while(afterCipher > UPPER_BOUND) {
				int difference = afterCipher - UPPER_BOUND;
				afterCipher = LOWER_BOUND + difference - 1;
			}
			caeserCipher = caeserCipher + (char)afterCipher;//adds next encrypted character to encrypted string
		}
		return caeserCipher;
	}
	
	/**
	 * Encrypts a string according the Bellaso Cipher.  Each character in plainText is offset 
	 * according to the ASCII value of the corresponding character in bellasoStr, which is repeated
	 * to correspond to the length of plainText
	 * @param plainText an uppercase string to be encrypted.
	 * @param bellasoStr an uppercase string that specifies the offsets, character by character.
	 * @return the encrypted string
	 */
	public static String encryptBellaso(String plainText, String bellasoStr) { //encrypts the users password using the Bellaso
		//cipher and incorporates the given key
		String bellasoCipher = "";
		int beforeCipher;
		int afterCipher;
		if(bellasoStr.length() == 0) { //input validation
			return "You did not enter a desired word to encrypt, please enter one.";
		}
		for(int i=0;i<plainText.length();i++) {
			beforeCipher = plainText.charAt(i);
			afterCipher = beforeCipher + bellasoStr.charAt(i % bellasoStr.length());//incrementing plainText 
			while(afterCipher > UPPER_BOUND) {
				int difference = afterCipher - UPPER_BOUND;
				afterCipher = LOWER_BOUND + difference - 1;
			}
			bellasoCipher = bellasoCipher + (char)afterCipher;
		}
		return bellasoCipher;
	}
	
	/**
	 * Decrypts a string according to the Caesar Cipher.  The integer key specifies an offset
	 * and each character in encryptedText is replaced by the character \"offset\" characters before it.
	 * This is the inverse of the encryptCaesar method.
	 * @param encryptedText an encrypted string to be decrypted.
	 * @param key an integer that specifies the offset of each character
	 * @return the plain text string
	 */
	public static String decryptCaesar(String encryptedText, int key) {  //decrypts the password using the Caesar cipher
		//and the user's key
		int beforeCipher;
		int afterCipher;
		String decryptedCaesar = "";
		for(int i=0;i<encryptedText.length(); i++) {
			beforeCipher = encryptedText.charAt(i);
			afterCipher = beforeCipher-key;//decrements by the users key to decode the cipher
			while(afterCipher < LOWER_BOUND) {
				int decrement = LOWER_BOUND - afterCipher;
				afterCipher = UPPER_BOUND - decrement + 1;
			}
			decryptedCaesar = decryptedCaesar + (char)afterCipher;
		}
		return decryptedCaesar;
	}
	
	/**
	 * Decrypts a string according the Bellaso Cipher.  Each character in encryptedText is replaced by
	 * the character corresponding to the character in bellasoStr, which is repeated
	 * to correspond to the length of plainText.  This is the inverse of the encryptBellaso method.
	 * @param encryptedText an uppercase string to be encrypted.
	 * @param bellasoStr an uppercase string that specifies the offsets, character by character.
	 * @return the decrypted string
	 */
	public static String decryptBellaso(String encryptedText, String bellasoStr) { //decrypts the users password
		//using the key. This is the bellaso method
		String decryptedBellaso = "";
		int beforeCipher;
		int afterCipher;
		if(bellasoStr.length() == 0) { //input validation
			return "Please enter a string to encrypt";
		}
		for(int i=0;i<encryptedText.length(); i++) {
			beforeCipher = encryptedText.charAt(i);
			afterCipher = beforeCipher - bellasoStr.charAt(i % bellasoStr.length());
			while(afterCipher < LOWER_BOUND) {
				int decrement = LOWER_BOUND - afterCipher;
				afterCipher = UPPER_BOUND - decrement + 1;
			}
			decryptedBellaso = decryptedBellaso + (char)afterCipher;
		}
		return decryptedBellaso;
	}
}