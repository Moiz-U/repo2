import static org.junit.Assert.*;

import java.util.ArrayList;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class MorseCodeTreeTest_STUDENT {

	MorseCodeTree binaryTree;

	@Before
	public void setUp() throws Exception {
		binaryTree = new MorseCodeTree();
	}

	@After
	public void tearDown() throws Exception {
		binaryTree = null;
	}

	@Test
	public void fetchTest() {
		String str = binaryTree.fetch(".-");
		assertEquals(str, "k");

		str = binaryTree.fetch(".-..");
		assertEquals(str, "w");
	}

	@Test
	public void toArrayListTest() {
		ArrayList<String> a = tree.toArrayList();
		assertEquals(a.get(22), "k");
		assertEquals(a.get(9), "r");
		assertEquals(a.get(7), "b");
		assertEquals(a.get(11), "");
	}

	@Test
	public void exceptionTest() {
		try {
			binaryTree.update();
		}
		catch(UnsupportedOperationException e)
		{
			assertTrue("unsupported operation exception was thrown", true);
		}
		
		try {
			binaryTree.delete("");
		}
		catch(UnsupportedOperationException e)
		{
			assertTrue("unsupported operation exception was thrown", true);
		}
	}
}
