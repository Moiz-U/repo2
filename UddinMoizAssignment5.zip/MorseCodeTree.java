import java.util.ArrayList;

public class MorseCodeTree implements LinkedConverterTreeInterface<String> {

	private TreeNode<String> node;

	/**
	 * constructor that calls buildtree
	 */
	public MorseCodeTree() {
		buildTree();
		node = null;
	}

	/**
	 * @return a reference to the root
	 */
	@Override
	public TreeNode<String> getRoot() {
		return node;
	}

	/**
	 * This method builds the MorseCodeTree by inserting the nodes of the tree level
	 * by level based on the code. The root will have a value of "" (empty string)
	 * level one: insert(".", "e"); insert("-", "t"); level two: insert("..", "i");
	 * insert(".-", "a"); insert("-.", "n"); insert("--", "m"); etc. Look at the
	 * tree and the table of codes to letters in the assignment description.
	 */
	@Override
	public void buildTree() {

		// tree root
		insert("", "");

		// 1
		insert(".", "e");
		insert("-", "t");

		// 2
		insert("..", "i");
		insert(".-", "a");
		insert("-.", "n");
		insert("--", "m");

		// 3
		insert("...", "s");
		insert("..-", "u");
		insert(".-.", "r");
		insert(".--", "w");
		insert("-..", "d");
		insert("-.-", "k");
		insert("--.", "g");
		insert("---", "o");

		// 4
		insert("....", "h");
		insert("...-", "v");
		insert("..-.", "f");
		insert(".-..", "l");
		insert(".--.", "p");
		insert(".---", "j");
		insert("-...", "b");
		insert("-..-", "x");
		insert("-.-.", "c");
		insert("-.--", "y");
		insert("--..", "z");
		insert("--.-", "q");

	}

	/**
	 * 
	 * Fetch the data in the tree based on the code This method will call the
	 * recursive method fetchNode
	 */
	@Override
	public String fetch(String word) {
		String str = fetchNode(node, word);
		return str;
	}

	/**
	 * 
	 * This is the recursive method that fetches the data of the TreeNode that
	 * corresponds with the code A '.' (dot) means traverse to the left. A "-"
	 * (dash) means traverse to the right. The code ".-" would fetch the data of the
	 * TreeNode stored as the right child of the left child of the root
	 */
	@Override
	public String fetchNode(TreeNode<String> root, String code) {
		String str = "";
		if ((code.length() > 1) == false) {
			if (code.equals(".")) {
				str = str + root.leftBranch.getData();
				return str;
			} else {
				str = str + root.rightBranch.getData();
				return str;
			}
		} else {
			if (code.charAt(0) == '.') {
				str = str + fetchNode(root.leftBranch, code.substring(1));
			} else {
				str = str + fetchNode(root.rightBranch, code.substring(1));
			}
		}
		return str;
	}

	/**
	 * This operation is not supported in the MorseCodeTree
	 */
	@Override
	public MorseCodeTree delete(String data) throws UnsupportedOperationException {
		throw new UnsupportedOperationException();
	}

	/**
	 * This operation is not supported in the MorseCodeTree
	 */
	@Override
	public MorseCodeTree update() throws UnsupportedOperationException {
		throw new UnsupportedOperationException();
	}

	/**
	 * Returns an ArrayList of the items in the linked Tree in LNR (Inorder)
	 * Traversal order Used for testing to make sure tree is built correctly
	 */
	@Override
	public ArrayList<String> toArrayList() {
		ArrayList<String> arr = new ArrayList<String>();
		LNRoutputTraversal(node, arr);
		return arr;
	}

	/**
	 * set root of morse code tree
	 */
	@Override
	public void setRoot(TreeNode<String> newNode) {
		node = new TreeNode<String>(newNode);
	}

	/**
	 * Adds element to the correct position in the tree based on the code This
	 * method will call the recursive method addNode
	 */
	@Override
	public void insert(String word, String letter) {
		// true
		if (node != null) {
			addNode(node, word, letter);
		} else {
			node = new TreeNode<String>(letter);
		}
		return;
	}
	
	
	@Override
	public void LNRoutputTraversal(TreeNode<String> root, ArrayList<String> list) {
		if (root.leftBranch != null && root.rightBranch != null) {
			if (root.rightBranch != null) {
				LNRoutputTraversal(root.rightBranch, list);
			} else if (root.leftBranch != null) {
				LNRoutputTraversal(root.leftBranch, list);
				list.add(root.getData() + " ");
			} else {
				list.add(root.getData() + " ");
			}

		}

	}

	/**
	 * This is a recursive method that adds element to the correct position in the
	 * tree based on the code. A '.' (dot) means traverse to the left. A "-" (dash)
	 * means traverse to the right. The code ".-" would be stored as the right child
	 * of the left child of the root Algorithm for the recursive method: 1. if there
	 * is only one character a. if the character is '.' (dot) store to the left of
	 * the current root b. if the character is "-" (dash) store to the right of the
	 * current root c. return 2. if there is more than one character a. if the first
	 * character is "." (dot) new root becomes the left child b. if the first
	 * character is "-" (dash) new root becomes the right child c. new code becomes
	 * all the remaining characters in the code (beyond the first character) d. call
	 * addNode(new root, new code, letter)
	 */
	@Override
	public void addNode(TreeNode<String> root, String word, String letter) {
		// checks if the given code is longer than 1 or not
		if ((word.length() > 1) == false) {
			if (word.equals(".")) {
				root.leftBranch = new TreeNode<String>(letter);
			} else {
				root.rightBranch = new TreeNode<String>(letter);
			}
		} else {
			if (word.charAt(0) != '-') {
				addNode(root.leftBranch, word.substring(1), letter);
			} else {
				addNode(root.rightBranch, word.substring(1), letter);
			}
		}
	}


}