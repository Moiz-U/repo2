import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

public class MorseCodeConverter {
	private static MorseCodeTree node = new MorseCodeTree();

	/**
	 * constructor
	 */
	public MorseCodeConverter() {

	}
	
	
	/**
	 * Converts a file of Morse code into English Each letter is delimited by a
	 * space (� �).
	 * 
	 * @param morse code from given text file, this method only deals with the
	 *              contents of the file
	 * @return morse to english translation
	 */
	public static String convertToEnglish(String givenMorse) {
		String[] letters;
		String[] words;
		String output = "";
		words = givenMorse.split("/");
		for (int i = 0; i < words.length; i++) {
			words[i] = words[i].trim();
			letters = words[i].split(" ");
			//nested for loop in order to look at the letters inside of the words
			for (int j = 0; j < letters.length; j++) {
				output += node.fetch(letters[j]);
			}
			output += " ";
		}
		output = output.trim();
		return output;
	}

	/**
	 * returns string in LNR form with a space separating it
	 * 
	 * @return
	 */
	public static String printTree() {
		String str = "";
		/*
		 * for (int i = 0; i < (tree.toArrayList()).size(); i++) { str = str + s;
		 * System.out.print(s); }
		 */
		for (String arr : node.toArrayList()) {
			str = str + arr;
			System.out.print(arr);
		}
		return str.trim();
	}

	/**
	 * Converts a file of Morse code into English Each letter is delimited by a
	 * space (� �).
	 * 
	 * @param ____ name of the file with the morsecode this can change depending on
	 *             file name so I used a placeholder name
	 * @return morse to english translation
	 */
	public static String convertToEnglish(File morsecode) throws FileNotFoundException {
		String str = "";
		Scanner sc = new Scanner(morsecode);
		while (sc.hasNext()) {
			// convertToEnglish method being called initialized below
			str = str + convertToEnglish(sc.nextLine());
		}
		return str;
	}


}
