public class TreeNode<T> {
	/**
	 * attributes of the class
	 * type parameter T
	 */
	private T data;
	protected TreeNode<T> rightBranch;
	protected TreeNode<T> leftBranch;

	
	/**
	 * Method
	 * Modifier T
	 * Return the data within this TreeNode
	 * @return data
	 */
	public T getData() {
		return data;
	}
	
	/**
	 * Constructor
	 * Used to make deep copies
	 * @param node
	 */
	public TreeNode(TreeNode<T> r, TreeNode<T> l, T d) {
		data = d;
		rightBranch = new TreeNode<T>(r);
		leftBranch = new TreeNode<T>(l);

	}
	
	public TreeNode(TreeNode<T> node) {
		this(node.rightBranch, node.leftBranch, node.getData());
	}
	
	/**
	 * Constructor
	 * Create a new TreeNode with left and right child set to null and
	 * data set to the dataNode
	 **/
	public TreeNode(T dataNode) {
		data = dataNode;
		leftBranch = null;
		rightBranch = null;
	}


}
