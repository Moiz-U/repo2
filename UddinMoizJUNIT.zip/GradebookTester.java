/*


 * Class: CMSC204-38176
 * Instructor: Farnaz Eivazi
 * Assignment: JUnit Lab
 * Due: 2/15/2022
 * Platform/compiler: Eclipse 
 * I pledge that I have completed the programming assignment independently.
   I have not copied the code from a student or any source.
   I have not given my code to any student.
   Print your Name here: Moiz Uddin
*/

import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;


public class GradebookTester {
	private GradeBook grade1;
	private GradeBook grade2;
	
	@Before
	public void setUp() {
		grade1 = new GradeBook(5);
		grade1.addScore(50);
		grade1.addScore(75);
		grade1.addScore(100);
		grade1.addScore(90);
		
		grade2 = new GradeBook(5);
		grade2.addScore(10);
		grade2.addScore(25);
		grade2.addScore(50);
		grade2.addScore(75);
	}

	
	@After
	public void tearDown() {
		grade1 = null;
		grade2 = null;
	}

	
	@Test
	public void testAddScore() {

		grade1 = new GradeBook(3);
		grade2 = new GradeBook(3);
		
		
		//g1
		assertEquals(0, grade1.getScoreSize());
		assertEquals(0, grade1.sum(), 0.0001);

		grade1.addScore(99);

		assertEquals(1, grade1.getScoreSize());
		assertEquals(99, grade1.sum(), 0.0001);

		grade1.addScore(25);

		assertEquals(2, grade1.getScoreSize());
		assertEquals(99 + 25, grade1.sum(), 0.0001);

		grade1.addScore(77);

		assertEquals(3, grade1.getScoreSize());
		assertEquals(99 + 25 + 77, grade1.sum(), 0.0001);
		assertFalse(grade1.addScore(87));
		assertEquals(3, grade1.getScoreSize());
		assertEquals(99 + 25 + 77, grade1.sum(), 0.0001);
		
		
		//g2
		assertEquals(0, grade2.getScoreSize());
		assertEquals(0, grade2.sum(), 0.0001);

		grade2.addScore(99);

		assertEquals(1, grade2.getScoreSize());
		assertEquals(99, grade2.sum(), 0.0001);

		grade2.addScore(25);

		assertEquals(2, grade2.getScoreSize());
		assertEquals(99 + 25, grade2.sum(), 0.0001);

		grade2.addScore(77);

		assertEquals(3, grade2.getScoreSize());
		assertEquals(99 + 25 + 77, grade2.sum(), 0.0001);
		assertFalse(grade1.addScore(87));
		assertEquals(3, grade1.getScoreSize());
		assertEquals(99 + 25 + 77, grade2.sum(), 0.0001);

	}

	@Test

	public void testSum() {
		assertEquals(50 + 75 + 100 + 90, grade1.sum(), 0.0001);
		grade1.addScore(55);
		assertEquals(50 + 75 + 100 + 90 + 55, grade1.sum(), 0.0001);
		
		assertEquals(10 + 25 + 50 + 75, grade2.sum(), 0.0001);
		grade2.addScore(55);
		assertEquals(10 + 25 + 50 + 75 + 55, grade2.sum(), 0.0001);

	}

	@Test

	public void testMinimum() {

		assertEquals(50, grade1.minimum(), 0.0001);
		grade1.addScore(22);
		assertEquals(22, grade1.minimum(), 0.0001);
		
		assertEquals(10, grade2.minimum(), 0.0001);
		grade2.addScore(5);
		assertEquals(5, grade2.minimum(), 0.0001);

	}

	@Test

	public void testFinalScore() {

		assertEquals(75 + 100 + 90, grade1.finalScore(), 0.0001);
		grade1.addScore(22);
		assertEquals(50 + 75 + 100 + 90, grade1.finalScore(), 0.0001);
		grade1 = new GradeBook(2);
		assertEquals(0, grade1.finalScore(), 0.0001);
		
		assertEquals(25 + 50 + 75, grade2.finalScore(), 0.0001);
		grade2.addScore(5);
		assertEquals(10 + 25 + 50 + 75, grade2.finalScore(), 0.0001);
		grade2 = new GradeBook(2);
		assertEquals(0, grade2.finalScore(), 0.0001);

	}

	@Test

	public void testGetScoreSize() {

		assertEquals(4, grade1.getScoreSize());
		grade1.addScore(22);
		assertEquals(5, grade1.getScoreSize());
		grade1.addScore(76);
		assertEquals(5, grade1.getScoreSize());
		
		assertEquals(4, grade2.getScoreSize());
		grade2.addScore(22);
		assertEquals(5, grade2.getScoreSize());
		grade2.addScore(76);
		assertEquals(5, grade2.getScoreSize());

	}

	@Test

	public void testToString() {
		assertTrue(grade1.toString().equals("50.0 75.0 100.0 90.0"));
		grade1.addScore(22);
		assertTrue(grade1.toString().equals("50.0 75.0 100.0 90.0 22.0"));
		grade1.addScore(80);
		assertTrue(grade1.toString().equals("50.0 75.0 100.0 90.0 22.0"));
		
		assertTrue(grade2.toString().equals("10.0 25.0 50.0 75.0"));
		grade2.addScore(22);
		assertTrue(grade2.toString().equals("10.0 25.0 50.0 75.0 22.0"));
		grade2.addScore(80);
		assertTrue(grade2.toString().equals("10.0 25.0 50.0 75.0 22.0"));

	}

}
